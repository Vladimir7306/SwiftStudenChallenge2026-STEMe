import SwiftUI

struct logIn: View {
    @State private var username1 = ""
    @State private var password = ""
    @State private var wrongUsername = 0
    @State private var wrongPassword = 0
    @State private var showLogIn = false
    
    var body: some View {
        NavigationStack{
            ZStack{
                AppTheme.navy.ignoresSafeArea()
                Circle()
                    .scale(2.0)
                    .foregroundColor(AppTheme.emerald.opacity(0.20))
                Circle()
                    .scale(1.6)
                    .foregroundColor(AppTheme.emerald)
                Circle()
                    .scale(1.2)
                    .foregroundColor(AppTheme.navy.opacity(1.8))

                VStack{
                    Text("log In")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .padding()
                    
                    TextField("username", text: $username1)
                        .padding()
                        .foregroundColor(.black)
                        .frame(width: 300, height: 60)
                        .background()
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(wrongUsername))
                    SecureField("Password", text: $password)
                        .padding()
                        .foregroundColor(.black)
                        .frame(width: 300, height: 60)
                        .background()
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(wrongPassword))
                    
                    Button("Start"){
                        authentication(username1: username1, password: password)
                    }
                    .foregroundColor(.white)
                    .frame(width: 300, height: 55)
                    .background(AppTheme.emerald)
                    .cornerRadius(10)
                }
            }
            .navigationDestination(isPresented: $showLogIn) {
                questions()
            }
        }
    }

    private func authentication(username1: String, password: String){
        if username1.lowercased() == "admin" {
            wrongUsername = 0
            if password.lowercased() == "apple1" {
                wrongPassword = 0
                AppGlobals.username1 = username1
                showLogIn = true
            } else {
                wrongPassword = 2
            }
        } else {
            wrongUsername = 2
        }
    }
}

#Preview {
    logIn()
}

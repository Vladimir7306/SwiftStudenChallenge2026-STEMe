//
//  SwiftUIView.swift
//  STEMe
//
//  Created by Oscar Vladimir Medina Gonzalez  on 14/02/26.
//

import SwiftUI

struct launchScreen: View {
    @State private var Active: Bool = false
    let navy =  Color(red: 10/255, green: 28/255, blue: 58/255)
    let emerald = Color(red: 6/255, green: 122/255, blue: 94/255)
    var body: some View {
        if Active {
                logIn()
        } else {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(red: 10/255, green: 28/255, blue: 58/255), Color(red: 6/255, green: 122/255, blue: 94/255)], ),
                               startPoint: .topTrailing,
                               endPoint: .bottomLeading)
                .ignoresSafeArea(edges: .all)
                
                VStack {
                    Text("STEMe")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                }
            }
            .onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now()+2){
                    withAnimation{
                        Active = true
                    }
                }
            }
        }
    }
}

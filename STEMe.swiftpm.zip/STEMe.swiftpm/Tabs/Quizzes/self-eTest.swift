//
//  self-eTest.swift
//  STEMe
//
//  Converted to fixed-question self-efficacy survey (1–7 scale)
//

import Foundation
import SwiftUI
import SwiftData

@Model
final class SelfEfficacyResult {
    @Attribute(.unique) var id: UUID
    var username: String
    var field: String
    var career: String
    var date: Date
    var answers: [Int]
    var average: Double

    init(id: UUID = UUID(), username: String, field: String, career: String, date: Date = .now, answers: [Int]) {
        self.id = id
        self.username = username
        self.field = field
        self.career = career
        self.date = date
        self.answers = answers
        self.average = answers.isEmpty ? 0 : Double(answers.reduce(0, +)) / Double(answers.count)
    }
}

// MARK: - Fixed-question ViewModel
@MainActor
final class SelfEfficacySurveyViewModel: ObservableObject {
    @Published var username: String = "Student"
    @Published var field: String = ""
    @Published var career: String = ""

    // You can edit these questions as needed
    @Published var questions: [String] = [
        "I feel confident starting a new STEM task even if it looks challenging.",
        "When I face a difficult problem, I can usually find a way to solve it.",
        "I stay motivated to complete STEM tasks even after setbacks.",
        "I believe I can learn the skills needed to succeed in STEM.",
        "I can manage my time effectively when working on STEM assignments.",
        "I can explain my reasoning clearly when solving STEM problems.",
        "I can find resources or help when I get stuck.",
        "I feel comfortable applying what I’ve learned to new situations."
    ] { didSet { syncAnswersCount() } }

    // Answers per question (1–7). Use 0 to represent unanswered.
    @Published var answers: [Int]

    @Published var didFinish: Bool = false

    private var modelContext: ModelContext?

    init(modelContext: ModelContext? = nil, username: String = "Student", field: String = "", career: String = "") {
        // Assign all stored properties without using self-dependent values
        self.modelContext = modelContext
        self.username = username
        self.field = field
        self.career = career
        // Initialize answers minimally; we'll size it after initialization is complete
        self.answers = []
        // Now that self is initialized, size answers to match questions
        self.answers = Array(repeating: 0, count: self.questions.count)
        syncAnswersCount()
    }

    private func syncAnswersCount() {
        if answers.count < questions.count {
            answers.append(contentsOf: Array(repeating: 0, count: questions.count - answers.count))
        } else if answers.count > questions.count {
            answers = Array(answers.prefix(questions.count))
        }
    }

    func attachModelContext(_ context: ModelContext) { self.modelContext = context }

    var isComplete: Bool { !answers.contains(0) }

    func setAnswer(_ value: Int, for index: Int) {
        guard (1...7).contains(value), questions.indices.contains(index) else { return }
        answers[index] = value
    }

    func submit() {
        guard isComplete, let ctx = modelContext else { return }
        let result = SelfEfficacyResult(username: username, field: field, career: career, answers: answers)
        ctx.insert(result)
        try? ctx.save()
        didFinish = true
    }
}

// MARK: - Survey View
struct selfeChatView: View { // Keep the same type name to avoid breaking navigation from Questions
    @Environment(\.modelContext) private var modelContext
    @Query private var selections: [UserSelection]
    @StateObject private var model = SelfEfficacySurveyViewModel()

    @State private var navigateToQuiz: Bool = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                header

                ForEach(Array(model.questions.enumerated()), id: \.offset) { index, text in
                    QuestionCard(index: index + 1, text: text, selected: model.answers[index]) { value in
                        model.setAnswer(value, for: index)
                    }
                }

                HStack {
                    Spacer()
                    Button(action: { model.submit() }) {
                        Text("Continue")
                            .fontWeight(.semibold)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .foregroundStyle(.white)
                            .background(model.isComplete ? AppTheme.emerald : Color.gray)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .disabled(!model.isComplete)
                    Spacer()
                }
                .padding(.top, 8)
            }
            .padding(16)
        }
        .scrollContentBackground(.hidden)
        .background(AppTheme.navy)
        .onAppear { prefillFromSelection() }
        .onChange(of: model.didFinish) { _, newValue in
            if newValue { navigateToQuiz = true }
        }
        .navigationTitle("Self‑Efficacy Test")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(AppTheme.navy, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .navigationDestination(isPresented: $navigateToQuiz) {
            ChatView()
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Please rate each statement from 1 (Strongly Disagree) to 7 (Strongly Agree).")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.8))
        }
    }

    private func prefillFromSelection() {
        model.attachModelContext(modelContext)
        if let last = selections.last {
            model.username = last.username
            model.field = last.field
            model.career = last.career
        }
    }
}

// MARK: - UI Components
private struct QuestionCard: View {
    let index: Int
    let text: String
    let selected: Int // 0 if none
    let onSelect: (Int) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Q\(index). \(text)")
                .font(.headline)
                .foregroundStyle(.white)

            ScaleSelector(selected: selected, onSelect: onSelect)
        }
        .padding(12)
        .background(
            Color.white.opacity(0.12),
            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
        )
    }
}

private struct ScaleSelector: View {
    let selected: Int
    let onSelect: (Int) -> Void

    var body: some View {
        HStack(spacing: 6) {
            ForEach(1...7, id: \.self) { value in
                Button(action: { onSelect(value) }) {
                    Text(String(value))
                        .frame(width: 34, height: 34)
                        .background(background(for: value))
                        .foregroundStyle(foreground(for: value))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
            Spacer()
        }
    }

    private func background(for value: Int) -> Color {
        selected == value ? AppTheme.yellow : Color.white.opacity(0.15)
    }

    private func foreground(for value: Int) -> Color {
        selected == value ? AppTheme.navy : .white
    }
}

#Preview("Self‑Efficacy Survey") {
    NavigationStack { selfeChatView() }
}


import Foundation
import SwiftUI

@MainActor
final class SelfEfficacySurveyViewModel: ObservableObject {
    static let defaultQuestions: [String] = [
        "I feel confident starting a new task even if it looks challenging.",
        "When I face a difficult problem, i can usually find a way to solve it.",
        "I stay motivated to complete the tasks even after setbacks.",
        "I believe I can learn the skills needed to succeed in this career.",
        "I can manage my time effectively when working on this career assignments.",
        "I can explain my reasoning clearly when solving problems related to this career.",
        "I can find resources or help when i get stuck.",
        "I feel comfortable applying what i’ve learned to new situations."
    ]

    @Published var username: String = "Student"
    @Published var field: String = ""
    @Published var career: String = ""
    @Published var questions: [String] = defaultQuestions { didSet { syncAnswersCount() } }
    @Published var answers: [Int]
    @Published var didFinish: Bool = false

    init() {
        let q = Self.defaultQuestions
        self.username = AppGlobals.username1.isEmpty ? "Student" : AppGlobals.username1
        self.field = AppGlobals.field
        self.career = AppGlobals.career
        self.answers = Array(repeating: 0, count: q.count)
        self.questions = q
    }

    private func syncAnswersCount() {
        if answers.count < questions.count {
            answers.append(contentsOf: Array(repeating: 0, count: questions.count - answers.count))
        } else if answers.count > questions.count {
            answers = Array(answers.prefix(questions.count))
        }
    }

    var isComplete: Bool { !answers.contains(0) }

    func setAnswer(_ value: Int, for index: Int) {
        guard (1...7).contains(value), questions.indices.contains(index) else { return }
        answers[index] = value
    }

    func submit() {
        guard isComplete else { return }
        AppGlobals.answers = answers
        AppGlobals.answersAverage = answers.isEmpty ? 0 : Double(answers.reduce(0, +)) / Double(answers.count)
        didFinish = true
    }
}

struct selfeChatView: View {
    var autoNavigateToQuiz: Bool = true
    @StateObject private var model = SelfEfficacySurveyViewModel()

    @State private var navigateToQuiz: Bool = false
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                header

                ForEach(Array(model.questions.enumerated()), id: \.offset) { index, text in
                    QuestionCard(index: index + 1, text: text, selected: model.answers[index]) { value in
                        model.setAnswer(value, for: index)
                    }
                }

                HStack {
                    Spacer()
                    Button(action: { model.submit() }) {
                        Text("Continue")
                            .fontWeight(.semibold)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .foregroundStyle(.white)
                            .background(model.isComplete ? AppTheme.emerald : Color.gray)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .disabled(!model.isComplete)
                    Spacer()
                }
                .padding(.top, 8)
            }
            .padding(16)
        }
        .scrollContentBackground(.hidden)
        .background(AppTheme.navy)
        .onChange(of: model.didFinish) { _, newValue in
            if newValue {
                if autoNavigateToQuiz {
                    navigateToQuiz = true
                } else {
                    dismiss()
                }
            }
        }
        .navigationTitle("Self‑Efficacy Test")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(AppTheme.navy, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .navigationDestination(isPresented: $navigateToQuiz) {
            ChatView()
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Based in the career yo selected. Please rate each statement from 1 (Strongly Disagree) to 7 (Strongly Agree).")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.8))
        }
    }
}

private struct QuestionCard: View {
    let index: Int
    let text: String
    let selected: Int 
    let onSelect: (Int) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Q\(index). \(text)")
                .font(.headline)
                .foregroundStyle(.white)

            ScaleSelector(selected: selected, onSelect: onSelect)
        }
        .padding(12)
        .background(
            Color.white.opacity(0.12),
            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
        )
    }
}

private struct ScaleSelector: View {
    let selected: Int
    let onSelect: (Int) -> Void

    var body: some View {
        HStack(spacing: 6) {
            ForEach(1...7, id: \.self) { value in
                Button(action: { onSelect(value) }) {
                    Text(String(value))
                        .frame(width: 34, height: 34)
                        .background(background(for: value))
                        .foregroundStyle(foreground(for: value))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
            Spacer()
        }
    }

    private func background(for value: Int) -> Color {
        selected == value ? AppTheme.yellow : Color.white.opacity(0.15)
    }

    private func foreground(for value: Int) -> Color {
        selected == value ? AppTheme.navy : .white
    }
}

#Preview("Self‑Efficacy Survey") {
    NavigationStack { selfeChatView() }
}


// Global state for the app, accessible from anywhere without SwiftData
import Foundation

@MainActor
enum AppGlobals {
    static var username1: String = ""
    static var field: String = ""
    static var career: String = ""

    // Self‑efficacy survey
    static var answers: [Int] = []
    static var answersAverage: Double = 0

    // Quiz/Chat results
    static var weakTopics: [String] = []
}

import Foundation

@MainActor
enum AppGlobals {
    static var username1: String = ""
    static var field: String = ""
    static var career: String = ""
    static var answers: [Int] = []
    static var answersAverage: Double = 0
    static var weakTopics: [String] = []
}

//
//  questions.swift
//  STEMe
//
//  Created by Oscar Vladimir Medina Gonzalez  on 27/01/26.
// Puedo almacenar la informacion sobre la area y la carrea en swift data para despues darsela a mis chatbots, al de escenarios darle la carrera y talvez lo mismo para el de autosuficiencia pero para hacerlo mas simple podria ser unicamente el area

import SwiftUI
import SwiftData

@Model
final class UserSelection {
    @Attribute(.unique) var id: UUID
    var username: String
    var field: String
    var career: String
    var date: Date

    init(id: UUID = UUID(), username: String = "Student", field: String, career: String, date: Date = .now) {
        self.id = id
        self.username = username
        self.field = field
        self.career = career
        self.date = date
    }
}

struct questions: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var selections: [UserSelection]

    @State private var field = ""
    @State private var career = ""
    @State private var username: String = "Student"
    @State private var navigateNext: Bool = false

    var body: some View {
        NavigationStack {
            ScrollView {
                contentStack
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("Welcome to STEMe")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(AppTheme.navy, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .scrollContentBackground(.hidden)
            .background(AppTheme.navy)
            .navigationDestination(isPresented: $navigateNext) {
                selfeChatView()
            }
        }
    }

    var contentStack: some View {
        VStack(alignment: .center, spacing: 25) {
            Text("STEMe is a platform that connects you with mentors and peers in your field of interest.")
                .foregroundStyle(.white.opacity(0.8))
                .padding(10)

            VStack(alignment: .leading, spacing: 8) {
                Text("Your name")
                    .font(.headline)
                    .foregroundStyle(.white)
                TextField("Enter a username", text: $username)
                    .foregroundStyle(.white)
                    .padding(10)
                    .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
            }
            .padding(.top, 8)

            Text("Choose a field")
                .font(.headline)
                .foregroundStyle(.white)

            fieldButtons

            if !field.isEmpty {
                Divider().padding(.vertical, 8)
                Text("Choose a career in \(field.capitalized)")
                    .font(.headline)
                    .foregroundStyle(.white)
                careerButtons
            }

            if !career.isEmpty {
                HStack {
                    Spacer()
                    LiquidGlassNextButton(title: "Next") {
                        persistSelection()
                        navigateNext = true
                    }
                    .disabled(field.isEmpty || career.isEmpty)
                    Spacer()
                }
                .padding(.top, 12)
            }
        }
        .padding(.horizontal)
        .padding(.top, 35)
    }

    private var fieldButtons: some View {
        let buttons: [(title: String, key: String, color: Color)] = [
            ("Science", "science", AppTheme.emerald),
            ("Technology", "technology", AppTheme.yellow),
            ("Engineering", "engineering", .blue),
            ("Mathematics", "mathematics", .orange)
        ]
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(buttons, id: \.key) { item in
                Button(action: {
                    field = item.key
                    career = "" // reset career when field changes
                }) {
                    Text(item.title)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .foregroundStyle(.white)
                        .background(item.key == field ? item.color.opacity(0.9) : item.color)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var careerButtons: some View {
        let map: [String: [String]] = [
            "science": ["Biology", "Chemistry", "Physics", "Earth Science"],
            "technology": ["Software Development", "Cybersecurity", "Data Science", "IT Support"],
            "engineering": ["Mechanical", "Electrical", "Civil", "Biomedical"],
            "mathematics": ["Statistics", "Applied Math", "Pure Math", "Actuarial"]
        ]
        let careers = map[field, default: []]
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(careers, id: \.self) { c in
                Button(action: { career = c }) {
                    Text(c)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .foregroundStyle(.white)
                        .background(career == c ? Color.white.opacity(0.22) : Color.white.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func persistSelection() {
        // Replace previous selection for this username, keep one active selection
        if let existing = selections.first(where: { $0.username.lowercased() == username.lowercased() }) {
            existing.field = field
            existing.career = career
            existing.date = .now
        } else {
            let newSel = UserSelection(username: username, field: field, career: career)
            modelContext.insert(newSel)
        }
        try? modelContext.save()
    }
}

struct LiquidGlassNextButton: View {
    var title: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .fontWeight(.semibold)
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .foregroundStyle(AppTheme.navy)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(AppTheme.yellow.opacity(0.7), lineWidth: 1)
                )
                .shadow(color: AppTheme.navy.opacity(0.2), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    questions()
}


//
//  MODELO.swift
//  STEMe
//
// Created by Oscar Vladimir Medina Gonzalez  on 23/01/26.
// Este apartado es DESPUES DE el test de autosuficiencia, aqui se hace el quiz
// de los escenarios para ver las areas de oportunidad que se puede tener
// y despues recomendar los materiales


// Nota a futuro uno de los puntos que recalca mi investigacion es que a futuro no se sigue a la muestra que se evalua, el que el usuario pueda repetir el quiz es vital para ver su desarrollo

// tambien estos tequizzes serviran para la social persuassion que estudie, animando a los estudiantes. Ya que ya hicieron algo real, aunque muy controlado.

// Podemos hacer un juego de rol para que sea menos invasivo

import SwiftUI
import Foundation
import FoundationModels // Asumo que son dependencias de tu entorno
import Playgrounds
import SwiftData

// MARK: - SwiftData Models
@Model
final class UserProfile {
    @Attribute(.unique) var id: UUID
    var username: String
    var career: String

    init(id: UUID = UUID(), username: String, career: String) {
        self.id = id
        self.username = username
        self.career = career
    }
}

@Model
final class QuizAttempt {
    @Attribute(.unique) var id: UUID
    var username: String
    var career: String
    var date: Date
    var difficultyLevel: Int
    var weakTopics: [String]

    init(id: UUID = UUID(), username: String, career: String, date: Date = .now, difficultyLevel: Int, weakTopics: [String]) {
        self.id = id
        self.username = username
        self.career = career
        self.date = date
        self.difficultyLevel = difficultyLevel
        self.weakTopics = weakTopics
    }
}

// MARK: - App Models
struct IdentifiedWeakness: Identifiable, Hashable {
    let id = UUID()
    let topic: String
    let rationale: String
}

struct ChatMessage: Identifiable, Hashable {
    enum Role { case user, assistant }
    let id = UUID()
    let role: Role
    let text: String
}

// MARK: - ViewModel
@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var input: String = ""
    @Published var isSending: Bool = false
    @Published var errorMessage: String?

    // Context
    @Published var username: String = "Student"
    @Published var selectedCareer: String = ""
    @Published var difficultyLevel: Int = 1
    @Published var identifiedWeaknesses: [IdentifiedWeakness] = []
    @Published var awaitingUserAnswer: Bool = false

    private var session: LanguageModelSession?

    init() {
        let instructions = "You are a professional mentor in the student's selected STEM career. Create short scenario-based questions to probe foundational and intermediate topics. Ask one question at a time. After each user answer, briefly evaluate confidence and knowledge, and name 1-2 specific topics that need improvement using concise keywords. Keep responses under 4 sentences."
        self.session = LanguageModelSession(instructions: instructions)
    }

    // Configura la identidad y agrega el mensaje semilla solo una vez
    func setupProfile(username: String, career: String) {
        self.username = username
        self.selectedCareer = career
        
        if messages.isEmpty {
            messages.append(ChatMessage(role: .assistant, text: "Hi \(username)! We’ll practice scenarios for \(career.isEmpty ? "your STEM path" : career). I’ll ask one question at a time. When you’re ready, say ‘start’."))
        }
    }

    func resetForNextAttempt() {
        identifiedWeaknesses.removeAll()
        messages.removeAll()
        awaitingUserAnswer = false
        isSending = false
        errorMessage = nil
        difficultyLevel += 1
        
        messages.append(ChatMessage(role: .assistant, text: "Attempt \(difficultyLevel) — I’ll make it a bit tougher this time. Say ‘start’ when ready."))
    }

    func send() {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Prevención real de envíos múltiples o fuera de turno
        guard !trimmed.isEmpty, !isSending, !awaitingUserAnswer else { return }

        let userMessage = ChatMessage(role: .user, text: trimmed)
        messages.append(userMessage)
        input = ""
        isSending = true
        errorMessage = nil

        Task {
            do {
                guard let session = session else { return }
                
                let systemContext = "User: \(username) | Career: \(selectedCareer) | Difficulty: \(difficultyLevel). If user says 'start', ask first scenario. After user answers, provide brief feedback and list weak topics in a line starting with 'Weak:' followed by comma-separated keywords. Ask the next question only after feedback."
                
                let result = try await session.respond(to: "\(systemContext)\nUser: \(trimmed)")
                let reply = result.content

                await MainActor.run {
                    self.messages.append(ChatMessage(role: .assistant, text: reply))
                    self.isSending = false
                    self.awaitingUserAnswer = false // El asistente ya respondió, el usuario puede hablar
                    self.extractWeakTopics(from: reply)
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isSending = false
                }
            }
        }
    }

    private func extractWeakTopics(from reply: String) {
        guard let range = reply.range(of: "Weak:") else { return }
        let tail = reply[range.upperBound...]
        let line = tail.split(separator: "\n").first.map(String.init) ?? String(tail)
        let tokens = line.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        
        for t in tokens {
            let item = IdentifiedWeakness(topic: t, rationale: "Identified by scenario feedback")
            if !identifiedWeaknesses.contains(where: { $0.topic.lowercased() == item.topic.lowercased() }) {
                identifiedWeaknesses.append(item)
            }
        }
    }

    // Recibe el contexto directamente desde la Vista para guardar de forma segura
    func finishAndPersistAttempt(in context: ModelContext) {
        let topics = identifiedWeaknesses.map { $0.topic }
        let attempt = QuizAttempt(username: username, career: selectedCareer, difficultyLevel: difficultyLevel, weakTopics: topics)
        context.insert(attempt)
        try? context.save()
    }
}

// MARK: - View
struct ChatView: View {
    @Environment(\.modelContext) private var modelContext
    
    // Consulta directa y reactiva usando SwiftData
    @Query private var profiles: [UserProfile]
    
    @StateObject private var model = ChatViewModel()
    @State private var navigateToLinks: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(model.messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                        }
                        if model.isSending {
                            ProgressView().padding(.vertical, 8)
                        }
                    }
                    .padding(16)
                }
                .onChange(of: model.messages) { _, _ in
                    if let last = model.messages.last?.id {
                        withAnimation { proxy.scrollTo(last, anchor: .bottom) }
                    }
                }
            }

            Rectangle()
                .fill(Color.white.opacity(0.15))
                .frame(height: 1)

            HStack(spacing: 8) {
                TextField("Type your response…", text: $model.input, axis: .vertical)
                    .foregroundStyle(.white)
                    .padding(10)
                    .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
                    .lineLimit(1...5)
                    .disabled(model.isSending || model.awaitingUserAnswer)
                    .onSubmit { model.send() }

                LiquidGlassButton(isLoading: model.isSending, action: model.send)
                    .disabled(model.isSending || model.awaitingUserAnswer || model.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding(12)
        }
        .scrollContentBackground(.hidden)
        .background(AppTheme.navy)
        .onAppear {
            // Inicializa el perfil usando los datos de @Query
            if let profile = profiles.first {
                model.setupProfile(username: profile.username, career: profile.career)
            } else {
                model.setupProfile(username: "Student", career: "")
            }
        }
        .navigationTitle("STEM Quiz — \(model.selectedCareer.isEmpty ? "Practice" : model.selectedCareer)")
        .tint(.white)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Finish") {
                    // Pasamos el contexto de forma segura desde el entorno
                    model.finishAndPersistAttempt(in: modelContext)
                    navigateToLinks = true
                }
                .tint(AppTheme.emerald)
            }
            ToolbarItem(placement: .topBarLeading) {
                Button("Restart") { model.resetForNextAttempt() }
                    .tint(AppTheme.yellow)
            }
        }
        .navigationDestination(isPresented: $navigateToLinks) {
            LinkWrapperView(topics: model.identifiedWeaknesses.map { $0.topic })
        }
        .alert("Error", isPresented: Binding(get: { model.errorMessage != nil }, set: { _ in model.errorMessage = nil })) {
            Button("OK", role: .cancel) { model.errorMessage = nil }
        } message: {
            Text(model.errorMessage ?? "Unknown error")
        }
    }
}

// MARK: - Component Views
private struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.role == .assistant { Spacer(minLength: 0) }
            Text(message.text)
                .padding(12)
                .foregroundStyle(.white)
                .background(message.role == .user ? AppTheme.emerald : Color.white.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            if message.role == .user { Spacer(minLength: 0) }
        }
    }
}

struct LiquidGlassButton: View {
    var isLoading: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Group {
                if isLoading { ProgressView() } else { Image(systemName: "paperplane.fill") }
            }
            .padding(10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(AppTheme.yellow.opacity(0.6), lineWidth: 1)
            )
            .shadow(color: AppTheme.navy.opacity(0.2), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}



// El modelo da buenas sugerencias. Pero para la medicion de la autosuficiencia no creo que sea apropiado. No he hecho pruebas aun eso si



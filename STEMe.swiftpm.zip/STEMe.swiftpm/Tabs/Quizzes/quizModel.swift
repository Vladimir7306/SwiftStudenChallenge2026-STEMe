//
//  MODELO.swift
//  STEMe
//
// Created by Oscar Vladimir Medina Gonzalez  on 23/01/26.
// Este apartado es DESPUES DE el test de autosuficiencia, aqui se hace el quiz
// de los escenarios para ver las areas de oportunidad que se puede tener
// y despues recomendar los materiales


// Nota a futuro uno de los puntos que recalca mi investigacion es que a futuro no se sigue a la muestra que se evalua, el que el usuario pueda repetir el quiz es vital para ver su desarrollo

// tambien estos tequizzes serviran para la social persuassion que estudie, animando a los estudiantes. Ya que ya hicieron algo real, aunque muy controlado.

// Podemos hacer un juego de rol para que sea menos invasivo

import SwiftUI
import Foundation
import FoundationModels // Asumo que son dependencias de tu entorno
import Playgrounds

// MARK: - App Models
struct IdentifiedWeakness: Identifiable, Hashable {
    let id = UUID()
    let topic: String
    let rationale: String
}

struct ChatMessage: Identifiable, Hashable {
    enum Role { case user, assistant }
    let id = UUID()
    let role: Role
    let text: String
}

// MARK: - ViewModel
@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var input: String = ""
    @Published var isSending: Bool = false
    @Published var errorMessage: String?

    // Context
    @Published var username: String = AppGlobals.username1.isEmpty ? "Student" : AppGlobals.username1
    @Published var selectedCareer: String = AppGlobals.career
    @Published var difficultyLevel: Int = 1
    @Published var identifiedWeaknesses: [IdentifiedWeakness] = []
    @Published var awaitingUserAnswer: Bool = false

    private var session: LanguageModelSession?
    
    private var shouldExtractAfterNextAssistantReply: Bool = false

    private func isStartCommand(_ text: String) -> Bool {
        let t = text.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let commands: Set<String> = ["start", "comenzar", "empezar", "iniciar", "begin", "ready", "listo"]
        return commands.contains(t)
    }

    init() {
        let instructions = "You are a professional mentor in the student's selected STEM career. Create short scenario-based questions to probe foundational and intermediate topics. You must generate the scenarios and questions yourself. Never ask the user to provide a scenario. Ask one question at a time. When the user says 'start' (or similar), only ask the first scenario question and do not include any evaluation or a line beginning with 'Weak:'. After each user answer (not 'start'), briefly evaluate confidence and knowledge, and then list weak topics in a single line starting with 'Weak:' followed by comma-separated concise keywords. Keep responses under 4 sentences."
        self.session = LanguageModelSession(instructions: instructions)
    }

    // Configura la identidad y agrega el mensaje semilla solo una vez
    func setupProfile(username: String, career: String) {
        self.username = username
        self.selectedCareer = career
        
        let greetingText = "Hi \(username)! We’ll practice scenarios for \(career.isEmpty ? "your STEM path" : career). I’ll ask one question at a time. When you’re ready, say ‘start’."
        
        if messages.isEmpty {
                    messages.append(ChatMessage(role: .assistant, text: greetingText))
                } else if messages.count == 1, messages.first?.role == .assistant {
                    // Si SwiftData cargó un poco tarde, actualizamos el saludo inicial
                    messages[0] = ChatMessage(role: .assistant, text: greetingText)
                }
    }

    func resetForNextAttempt() {
        identifiedWeaknesses.removeAll()
        messages.removeAll()
        awaitingUserAnswer = false
        isSending = false
        errorMessage = nil
        difficultyLevel += 1
        
        messages.append(ChatMessage(role: .assistant, text: "Attempt \(difficultyLevel) — I’ll make it a bit tougher this time. Say ‘start’ when ready."))
        shouldExtractAfterNextAssistantReply = false
    }

    func send() {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        let isStart = isStartCommand(trimmed)
        
        // Prevención real de envíos múltiples o fuera de turno
        guard !trimmed.isEmpty, !isSending, !awaitingUserAnswer else { return }

        let userMessage = ChatMessage(role: .user, text: trimmed)
        messages.append(userMessage)
        input = ""
        self.shouldExtractAfterNextAssistantReply = !isStart
        isSending = true
        errorMessage = nil
        self.awaitingUserAnswer = true

        Task {
            do {
                guard let session = session else { return }
                
                let systemContext = "User: \(username) | Career: \(selectedCareer) | Difficulty: \(difficultyLevel). You must generate the scenario question yourself and never ask the user to provide a scenario. If user says 'start', ask the first scenario and do NOT include any 'Weak:' line. After a user answer (not 'start'), provide brief feedback and list weak topics in a line starting with 'Weak:' followed by comma-separated keywords. Ask the next question yourself only after feedback."
                
                let directive = isStart ? "The user initiated with 'start'. Provide the first scenario question now. Generate the scenario yourself and do not ask the user to propose one." : "The user has answered. Evaluate their answer briefly, then ask the next scenario question yourself. Do not ask the user to propose a scenario."
                let result = try await session.respond(to: "\(systemContext)\n\(directive)\nUser: \(trimmed)")
                let reply = result.content

                await MainActor.run {
                    self.messages.append(ChatMessage(role: .assistant, text: reply))
                    self.isSending = false
                    self.awaitingUserAnswer = false // El asistente ya respondió, el usuario puede hablar
                    if self.shouldExtractAfterNextAssistantReply {
                        self.extractWeakTopics(from: reply)
                    }
                    self.shouldExtractAfterNextAssistantReply = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isSending = false
                }
            }
        }
    }

    private func extractWeakTopics(from reply: String) {
        guard let range = reply.range(of: "Weak:") else { return }
        let tail = reply[range.upperBound...]
        let line = tail.split(separator: "\n").first.map(String.init) ?? String(tail)
        let tokens = line.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        
        for t in tokens {
            let item = IdentifiedWeakness(topic: t, rationale: "Identified by scenario feedback")
            if !identifiedWeaknesses.contains(where: { $0.topic.lowercased() == item.topic.lowercased() }) {
                identifiedWeaknesses.append(item)
            }
        }
    }

    // Recibe el contexto directamente desde la Vista para guardar de forma segura
    func finishAndPersistAttempt() {
        let topics = identifiedWeaknesses.map { $0.topic }
        AppGlobals.weakTopics = topics
    }
}

// MARK: - View
struct ChatView: View {
    @StateObject private var model = ChatViewModel()
    @State private var navigateToHome: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(model.messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                        }
                        if model.isSending {
                            ProgressView().padding(.vertical, 8)
                        }
                    }
                    .padding(16)
                }
                .onChange(of: model.messages) { _, _ in
                    if let last = model.messages.last?.id {
                        withAnimation { proxy.scrollTo(last, anchor: .bottom) }
                    }
                }
            }

            Rectangle()
                .fill(Color.white.opacity(0.15))
                .frame(height: 1)

            HStack(spacing: 8) {
                TextField("Type your response…", text: $model.input, axis: .vertical)
                    .foregroundStyle(.white)
                    .padding(10)
                    .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
                    .lineLimit(1...5)
                    .disabled(model.isSending || model.awaitingUserAnswer)
                    .onSubmit { model.send() }

                LiquidGlassButton(isLoading: model.isSending, action: model.send)
                    .disabled(model.isSending || model.awaitingUserAnswer || model.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding(12)
        }
        .scrollContentBackground(.hidden)
        .background(AppTheme.navy)
        .onAppear {
            model.setupProfile(username: AppGlobals.username1.isEmpty ? "Student" : AppGlobals.username1, career: AppGlobals.career)
        }
        .navigationTitle("STEM Quiz — \(model.selectedCareer.isEmpty ? "Practice" : model.selectedCareer)")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .bottomBar) {
                Button("Finish") {
                    model.finishAndPersistAttempt()
                    navigateToHome = true
                }
                .tint(AppTheme.emerald)
            }
            
            
            ToolbarItem(placement: .bottomBar) {
                Button("Restart") { model.resetForNextAttempt() }
                    .tint(AppTheme.yellow)
            }
        }
        .navigationDestination(isPresented: $navigateToHome) {
            HomeView()
        }
        .alert("Error", isPresented: Binding(get: { model.errorMessage != nil }, set: { _ in model.errorMessage = nil })) {
            Button("OK", role: .cancel) { model.errorMessage = nil }
        } message: {
            Text(model.errorMessage ?? "Unknown error")
        }
    }
}

// MARK: - Component Views
private struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.role == .assistant { Spacer(minLength: 0) }
            Text(message.text)
                .padding(12)
                .foregroundStyle(.white)
                .background(message.role == .user ? AppTheme.emerald : Color.white.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            if message.role == .user { Spacer(minLength: 0) }
        }
    }
}

struct LiquidGlassButton: View {
    var isLoading: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Group {
                if isLoading { ProgressView() } else { Image(systemName: "paperplane.fill") }
            }
            .padding(10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(AppTheme.yellow.opacity(0.6), lineWidth: 1)
            )
            .shadow(color: AppTheme.navy.opacity(0.2), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}

#Preview("Chatbot"){
    NavigationStack { ChatView() }
}

// El modelo da buenas sugerencias. Pero para la medicion de la autosuficiencia no creo que sea apropiado. No he hecho pruebas aun eso si




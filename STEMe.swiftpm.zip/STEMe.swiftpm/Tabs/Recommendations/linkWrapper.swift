//
//  File.swift
//  STEMe
//
//  Created by Oscar Vladimir Medina Gonzalez  on 02/02/26.
// Aqui se usara el wrapper de los links que no que como voy a hacer para
// mostrarlos y aparte de eso ver si son seguros. Ademas tengo qu mostrar los
// titulos de dichos link y que sean muy especificos con el problema que
// quiere resolver el usuario


import Foundation
import SwiftUI

struct ResourceItem: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let url: URL
    let topic: String
}

struct LinkWrapperView: View {
    @Environment(\.openURL) private var openURL

    // Topics can be injected directly; if empty, we will try to read the last attempt
    var topics: [String] = []

    private var resolvedTopics: [String] {
        if !topics.isEmpty { return topics }
        return AppGlobals.weakTopics
    }

    private var resources: [ResourceItem] {
        // Placeholder mapping. In a real app, fetch from your backend or a curated JSON bundle.
        var items: [ResourceItem] = []
        for t in resolvedTopics {
            let key = t.lowercased()
            switch key {
            case _ where key.contains("algebra"):
                if let url = URL(string: "https://www.khanacademy.org/math/algebra") {
                    items.append(ResourceItem(title: "Algebra foundations (Khan Academy)", url: url, topic: t))
                }
            case _ where key.contains("calculus"):
                if let url = URL(string: "https://www.khanacademy.org/math/calculus-1") {
                    items.append(ResourceItem(title: "Intro to Calculus (Khan Academy)", url: url, topic: t))
                }
            case _ where key.contains("program") || key.contains("coding"):
                if let url = URL(string: "https://developer.apple.com/tutorials/app-dev-training") {
                    items.append(ResourceItem(title: "Apple app dev training", url: url, topic: t))
                }
            case _ where key.contains("statistics"):
                if let url = URL(string: "https://www.khanacademy.org/math/statistics-probability") {
                    items.append(ResourceItem(title: "Statistics & probability (Khan Academy)", url: url, topic: t))
                }
            default:
                if let url = URL(string: "https://www.google.com/search?q=learn+\(key.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? key)") {
                    items.append(ResourceItem(title: "Learn more about \(t)", url: url, topic: t))
                }
            }
        }
        return items
    }

    var body: some View {
        VStack(alignment: .leading) {
            if resolvedTopics.isEmpty {
                ContentUnavailableView("No topics received", systemImage: "link", description: Text("Finish a quiz to identify topics that need practice."))
            } else {
                Text("Recommended resources")
                    .font(.largeTitle.bold())
                    .foregroundStyle(AppTheme.navy)
                    .padding(.bottom, 8)

                ForEach(resources) { item in
                    ResourceRow(item: item)
                        .onTapGesture { openURL(item.url) }
                        .padding(.vertical, 6)
                    Divider()
                }
            }
        }
        .padding()
        .navigationTitle("Practice Links")
    }
}

private struct ResourceRow: View {
    let item: ResourceItem

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "play.rectangle.fill")
                .foregroundStyle(AppTheme.yellow)
                .font(.title3)
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.headline)
                    .foregroundStyle(AppTheme.navy)
                Text(item.topic)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Link("Open", destination: item.url)
                    .tint(AppTheme.emerald)
            }
            Spacer()
        }
    }
}

#Preview("Link Wrapper") {
    NavigationStack {
        LinkWrapperView(topics: ["Algebra", "Programming Basics", "Statistics"])
    }
}


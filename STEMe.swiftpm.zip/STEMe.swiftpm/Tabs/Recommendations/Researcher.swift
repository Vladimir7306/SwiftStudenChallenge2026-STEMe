import Foundation
import SwiftUI
import FoundationModels


struct ResearcherView: View {
    var topics: [String] = []

    @State private var explanations: [String: String] = [:]
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    private var resolvedTopics: [String] {
        let t = topics.isEmpty ? AppGlobals.weakTopics : topics
        return t.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    var body: some View {
        ZStack {
            AppTheme.navy.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    header
                    if resolvedTopics.isEmpty {
                        ContentUnavailableView("No topics received", systemImage: "brain.head.profile", description: Text("Completa un quiz para identificar temas que requieren práctica."))
                            .foregroundStyle(.white)
                    } else {
                        if isLoading {
                            ProgressView("Generating data ...")
                                .tint(AppTheme.yellow)
                                .foregroundStyle(.white)
                        }
                        if let error = errorMessage {
                            Text(error)
                                .foregroundStyle(.red)
                        }
                        ForEach(resolvedTopics, id: \.self) { topic in
                            ExplanationCard(topic: topic, text: explanations[topic] ?? "")
                        }
                        if !resolvedTopics.isEmpty {
                            Button(action: generateExplanations) {
                                HStack {
                                    Image(systemName: "arrow.clockwise")
                                    Text("Re-Explain")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .foregroundStyle(AppTheme.navy)
                                .background(AppTheme.emerald, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            }
        }
        .navigationTitle("Researcher")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(AppTheme.navy, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .onAppear(perform: generateExplanations)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Lets learn new things today!")
                .font(.largeTitle.bold())
                .foregroundStyle(AppTheme.emerald)
            if !resolvedTopics.isEmpty {
                Text("Weak areas: \(resolvedTopics.joined(separator: ", "))")
                    .foregroundStyle(.white.opacity(0.8))
            }
        }
    }

    private func generateExplanations() {
        guard !resolvedTopics.isEmpty else { return }
        isLoading = true
        errorMessage = nil

        Task {
            do {
                let session = LanguageModelSession(instructions: "You are a stem professional. Explain with examples the following topics. Keep each explantion under 100 words.")
                var newExplanations: [String: String] = [:]
                for topic in resolvedTopics {
                    let context = "Username: \(AppGlobals.username1.isEmpty ? "Student" : AppGlobals.username1) | Carrera: \(AppGlobals.career). Tema: \(topic)."
                    let result = try await session.respond(to: "\(context) Explain the topic clearly and with examples.")
                    newExplanations[topic] = result.content
                }
                await MainActor.run {
                    self.explanations = newExplanations
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
}

private struct ExplanationCard: View {
    let topic: String
    let text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(topic)
                .font(.headline)
                .foregroundStyle(AppTheme.yellow)
            if text.isEmpty {
                Text("Thinking...")
                    .foregroundStyle(.white.opacity(0.7))
            } else {
                Text(text)
                    .foregroundStyle(.white)
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

#Preview("Researcher") {
    NavigationStack {
        ResearcherView(topics: ["Algebra", "Programming Basics", "Statistics"])
    }
}


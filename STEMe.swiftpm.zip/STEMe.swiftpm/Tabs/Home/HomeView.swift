import SwiftUI

struct HomeView: View {
    @State private var username: String = ""
    @State private var field: String = ""
    @State private var career: String = ""
    @State private var answersAverage: Double = 0
    @State private var weakTopics: [String] = []
    @State private var showSelfTest = false
    @State private var showScenarioQuiz = false
    @State private var showResources = false

    var body: some View {
        ZStack {
            AppTheme.navy.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    headerSection
                    infoCards
                    actionsSection
                }
                .padding(16)
            }
        }
        .navigationTitle("Home")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(AppTheme.navy, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .onAppear(perform: refreshFromGlobals)
        .navigationDestination(isPresented: $showSelfTest) { selfeChatView(autoNavigateToQuiz: false) }
        .navigationDestination(isPresented: $showScenarioQuiz) { ChatView() }
        .navigationDestination(isPresented: $showResources) { LinkWrapperView(topics: weakTopics) }
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Welcome back,")
                .foregroundStyle(.white.opacity(0.8))
            Text(username.isEmpty ? "Student" : username)
                .font(.largeTitle.bold())
                .foregroundStyle(AppTheme.emerald)
            if !career.isEmpty || !field.isEmpty {
                Text("\(career)\(career.isEmpty || field.isEmpty ? "" : " • ")\(field.capitalized)")
                    .foregroundStyle(.white.opacity(0.85))
            }
        }
    }

    private var infoCards: some View {
        VStack(spacing: 16) {
            // Self-efficacy average
            VStack(alignment: .leading, spacing: 8) {
                Text("Self-Eficcacy grade")
                    .font(.headline)
                    .foregroundStyle(.white)
                HStack {
                    Text(String(format: "%.1f / 7", answersAverage))
                        .font(.title2.bold())
                        .foregroundStyle(AppTheme.yellow)
                    Spacer()
                    Button("Grade myself again") { showSelfTest = true }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .foregroundStyle(AppTheme.navy)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(AppTheme.yellow.opacity(0.7), lineWidth: 1)
                        )
                        .buttonStyle(.plain)
                }
            }
            .padding(12)
            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            // Weak areas
            VStack(alignment: .leading, spacing: 8) {
                Text("Weak areas")
                    .font(.headline)
                    .foregroundStyle(.white)
                if weakTopics.isEmpty {
                    Text("You havent taken any scenarios yet. Make one to see your weak areas.")
                        .foregroundStyle(.white.opacity(0.75))
                } else {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(weakTopics, id: \.self) { topic in
                            HStack(spacing: 8) {
                                Circle().fill(AppTheme.yellow).frame(width: 6, height: 6)
                                Text(topic)
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                }
                HStack {
                    Spacer()
                    Button("New scenario") {
                        AppGlobals.username1 = username
                        AppGlobals.career = career
                        showScenarioQuiz = true
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .foregroundStyle(AppTheme.navy)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(AppTheme.emerald.opacity(0.7), lineWidth: 1)
                    )
                    .buttonStyle(.plain)
                }
                .padding(.top, 4)
            }
            .padding(12)
            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            // Profile basics
            VStack(alignment: .leading, spacing: 8) {
                Text("Profile")
                    .font(.headline)
                    .foregroundStyle(.white)
                keyValueRow(key: "Username", value: username.isEmpty ? "—" : username)
                keyValueRow(key: "Area", value: field.isEmpty ? "—" : field.capitalized)
                keyValueRow(key: "Career", value: career.isEmpty ? "—" : career)
            }
            .padding(12)
            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }

    private func keyValueRow(key: String, value: String) -> some View {
        HStack {
            Text(key)
                .foregroundStyle(.white.opacity(0.75))
            Spacer()
            Text(value)
                .foregroundStyle(AppTheme.yellow)
        }
    }

    private var actionsSection: some View {
        VStack(spacing: 12) {
            Button {
                showResources = true
            } label: {
                HStack {
                    Image(systemName: "link")
                    Text("Study resources")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .foregroundStyle(AppTheme.navy)
                .background(AppTheme.emerald, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 4)
    }

    private func refreshFromGlobals() {
        username = AppGlobals.username1
        field = AppGlobals.field
        career = AppGlobals.career
        answersAverage = AppGlobals.answersAverage
        weakTopics = AppGlobals.weakTopics
    }
}

#Preview("HomeView") {
    NavigationStack { HomeView() }
}


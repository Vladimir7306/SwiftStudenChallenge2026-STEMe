import SwiftUI
import Playgrounds

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
           launchScreen()
        }
    }
}

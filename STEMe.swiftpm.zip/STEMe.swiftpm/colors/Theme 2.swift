import SwiftUI

public struct AppTheme {
    public static let navy = Color(red: 10/255, green: 28/255, blue: 58/255)
    public static let emerald = Color(red: 6/255, green: 122/255, blue: 94/255)
    public static let yellow = Color(red: 255/255, green: 205/255, blue: 60/255)
}

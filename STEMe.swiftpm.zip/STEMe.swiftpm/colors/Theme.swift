import SwiftUI

struct SharedTheme {
    static let backgroundColor = AppTheme.navy.opacity(0.05)
    static let primaryTextColor = AppTheme.navy
    static let secondaryTextColor = AppTheme.yellow
    static let buttonColor = AppTheme.emerald
    static let buttonTextColor = Color.white
    static let cornerRadius: CGFloat = 8
    static let padding: CGFloat = 16
}

struct ContentView: View {
    var body: some View {
        VStack(spacing: SharedTheme.padding) {
            Text("Welcome to the App")
                .foregroundColor(SharedTheme.primaryTextColor)
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(SharedTheme.cornerRadius)
            
            Button(action: {
                print("Button tapped")
            }) {
                Text("Tap me")
                    .foregroundColor(SharedTheme.buttonTextColor)
                    .padding()
                    .background(SharedTheme.buttonColor)
                    .cornerRadius(SharedTheme.cornerRadius)
            }
            .tint(AppTheme.yellow)
        }
        .padding(SharedTheme.padding)
        .background(SharedTheme.backgroundColor)
    }
}
